package gp2;

import java.util.ArrayList;

import java.util.Scanner;

public class ejercicio03 {

    public static void main(String[] args) {
        // Crear un ArrayList de nombres de Pokémon
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        // Nuevo Pokémon a insertar
        String nuevoPokemon = "Pikachu";

        // Insertar el nuevo Pokémon en la primera posición
        nombresPokemon.add(0, nuevoPokemon);

        // Imprimir la lista después de la inserción
        System.out.println("Lista después de la inserción:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}
