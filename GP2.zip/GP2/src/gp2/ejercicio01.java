package gp2;

import java.util.ArrayList;

public class ejercicio01 {

    public static void main(String[] args) {
     
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        
        System.out.println("Nombres de Pokémon:");
        for (String nombre : nombresPokemon) {
            System.out.println(nombre);
        }
    }
}
