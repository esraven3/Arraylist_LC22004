package gp2;

import java.util.ArrayList;

public class ejercicio07 {

    public static void main(String[] args) {
      
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        
        String elementoABuscar = "Jigglypuff";

       
        int indice = nombresPokemon.indexOf(elementoABuscar);

      
        if (indice != -1) {
            System.out.println("El elemento \"" + elementoABuscar + "\" se encuentra en la posición " + indice + " de la lista.");
        } else {
            System.out.println("El elemento \"" + elementoABuscar + "\" no se encuentra en la lista.");
        }
    }
}
