package gp2;

import java.util.ArrayList;
import java.util.Collections;

public class ejercicio09 {

    public static void main(String[] args) {

        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        Collections.shuffle(nombresPokemon);

        System.out.println("Lista después de mezclar:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}
