package gp2;

import java.util.ArrayList;

public class ejercicio12 {

    public static void main(String[] args) {
        ArrayList<String> primerConjuntoPokemon = new ArrayList<>();
        primerConjuntoPokemon.add("Pikachu");
        primerConjuntoPokemon.add("Charizard");
        primerConjuntoPokemon.add("Bulbasaur");

        ArrayList<String> segundoConjuntoPokemon = new ArrayList<>();
        segundoConjuntoPokemon.add("Bulbasaur");
        segundoConjuntoPokemon.add("Squirtle");
        segundoConjuntoPokemon.add("Jigglypuff");

        if (primerConjuntoPokemon.equals(segundoConjuntoPokemon)) {
            System.out.println("¿Los conjuntos de Pokémon si son iguales");
        } else {
            System.out.println("¿Los conjuntos de Pokémon no son iguales");
        }
    }
}
