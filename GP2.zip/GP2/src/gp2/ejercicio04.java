package gp2;

public class ejercicio04 {

    public static void main(String[] args) {
        String[] pokemons = {"Pikachu", "Charizard", "Bulbasaur", "Squirtle", "Jigglypuff", "Eevee", "Mewtwo", "Gyarados", "Snorlax", "Vulpix"};
        int indiceEspecificado = 2;

        // Verificar si el índice está dentro del rango del array
        if (indiceEspecificado >= 0 && indiceEspecificado < pokemons.length) {
            String pokemonEnIndice = pokemons[indiceEspecificado];
            System.out.println("POKEMON EN EL INDICE " + indiceEspecificado + ": " + pokemonEnIndice);
        } else {
            System.out.println("El índice especificado está fuera del rango del array.");
        }
    }
}
