package gp2;

import java.util.ArrayList;

public class ejercicio02 {

    public static void main(String[] args) {
       
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");
        nombresPokemon.add("Eevee");
        nombresPokemon.add("Mewtwo");
        nombresPokemon.add("Gyarados");
        nombresPokemon.add("Snorlax");
        nombresPokemon.add("Vulpix");

     
        ArrayList<Integer> numeros = new ArrayList<>();
        for (int i = 1; i <= 10; i++) {
            numeros.add(i);
        }


        ArrayList<Character> caracteres = new ArrayList<>();
        for (char c = 'A'; c <= 'J'; c++) {
            caracteres.add(c);
        }

  
        System.out.println("Nombres de Pokémon:");
        for (String nombre : nombresPokemon) {
            System.out.println(nombre);
        }

        
        System.out.println("\nNúmeros:");
        for (int numero : numeros) {
            System.out.println(numero);
        }

       
        System.out.println("\nCaracteres:");
        for (char caracter : caracteres) {
            System.out.println(caracter);
        }
    }
}
