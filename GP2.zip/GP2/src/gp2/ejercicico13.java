package gp2;

import java.util.ArrayList;
import java.util.Collections;

public class ejercicico13 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        int indice1 = 0;
        int indice2 = 4;

        Collections.swap(nombresPokemon, indice1, indice2);

        System.out.println("Lista después del intercambio:");
        for (String nombre : nombresPokemon) {
            System.out.println(nombre);
        }
    }
}
