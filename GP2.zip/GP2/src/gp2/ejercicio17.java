package gp2;

import java.util.ArrayList;

public class ejercicio17 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();

        if (nombresPokemon.isEmpty()) {
            System.out.println("El ArrayList está vacío.");
        } else {
            System.out.println("El ArrayList no está vacío.");
        }
    }
}
