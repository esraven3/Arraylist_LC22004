package gp2;

import java.util.ArrayList;

public class ejercicio18 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        int nuevaCapacidad = 3;

        ArrayList<String> nuevoArrayList = new ArrayList<>(nombresPokemon.subList(0, nuevaCapacidad));
        nombresPokemon = nuevoArrayList;

        System.out.println("Lista después de reducir la capacidad:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}
