package gp2;

import java.util.ArrayList;
import java.util.Collections;

public class ejercicio08 {

    public static void main(String[] args) {
        
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        
        System.out.println("Lista desordenada:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }

    
        Collections.sort(nombresPokemon);

        
        System.out.println("\nLista después de ordenar alfabéticamente:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}