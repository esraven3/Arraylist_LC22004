//En realidad es el 9 pero no lo vi y ahora cada uno de 
//9 en adelanyte esta desplasado un numero
package gp2;

import java.util.ArrayList;

public class ejercicio22 {

    public static void main(String[] args) {
        ArrayList<String> original = new ArrayList<>();
        original.add("Pikachu");
        original.add("Charizard");
        original.add("Bulbasaur");

        ArrayList<String> copia = new ArrayList<>();
        copia.addAll(original);

        System.out.println("ArrayList original: " + original);
        System.out.println("ArrayList copia: " + copia);
    }
}
