package gp2;

import java.util.ArrayList;

public class ejercicio19 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");

        // Nuevo tamaño deseado
        int nuevoTamaño = 5;

        // Aumentar el tamaño del ArrayList agregando elementos null
        while (nombresPokemon.size() < nuevoTamaño) {
            nombresPokemon.add(null);
        }

        // Imprimir la lista después de aumentar el tamaño
        System.out.println("Lista después de aumentar el tamaño:");
        for (String nombre : nombresPokemon) {
            System.out.println(nombre);
        }
    }
}
