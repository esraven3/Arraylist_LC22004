package gp2;

import java.util.ArrayList;
import java.util.Collections;

public class ejercicio10 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        System.out.println("Lista original:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }

        Collections.reverse(nombresPokemon);

        System.out.println("\nLista después de invertir los elementos:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}
