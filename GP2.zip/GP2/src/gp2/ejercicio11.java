package gp2;

import java.util.ArrayList;

public class ejercicio11 {

    public static void main(String[] args) {
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        int indiceInicio = 1;
        int indiceFin = 4;

        ArrayList<String> porcionExtraida = new ArrayList<>(nombresPokemon.subList(indiceInicio, indiceFin));

        System.out.println("Porción extraída:");
        for (String nombre : porcionExtraida) {
            System.out.println(nombre);
        }
    }
}
