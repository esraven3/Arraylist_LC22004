
package gp2;

import java.util.ArrayList;

public class ejercicio06 {
    public static void main(String[] args) {
        // Crear un ArrayList de nombres de Pokémon
        ArrayList<String> nombresPokemon = new ArrayList<>();
        nombresPokemon.add("Pikachu");
        nombresPokemon.add("Charizard");
        nombresPokemon.add("Bulbasaur");
        nombresPokemon.add("Squirtle");
        nombresPokemon.add("Jigglypuff");

        // Imprimir la lista antes de eliminar el tercer elemento
        System.out.println("Lista antes de eliminar el tercer elemento:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
        
        // Eliminar el tercer elemento (índice 2) del ArrayList
        nombresPokemon.remove(2);

        // Imprimir la lista después de eliminar el tercer elemento
        System.out.println("\nLista después de eliminar el tercer elemento:");
        for (String nombre : nombresPokemon) {
            System.out.println("\"" + nombre + "\"");
        }
    }
}